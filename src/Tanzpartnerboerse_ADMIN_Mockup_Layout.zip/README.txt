Admin-Dashboard – Mockup Layout

Geändert:
- Admin-Startseite im Stil des gewünschten Mockups neu aufgebaut.
- Gleiche pastel/purple Farbwelt, große nächste Veranstaltung, 4 kompakte Kennzahlen.
- Seitenöffnungen als eigene kompakte Statistikzeile.
- Schnellzugriff als 2-spaltige Karten + breite Tanzpartnervermittlung.
- Weitere Verwaltung in aufklappbaren Kategorien.
- Bestehende Aktionen/Views und Ladefunktionen der Admin-Seite bleiben erhalten.
- Neue Kategorie-Navigation: Teilnehmer & Nutzer, Workshops & Tanzkreis, Inhalte & Darstellung, Drucken & PDFs, Meldungen, Einstellungen.

Datei:
main_tanzpartnerboerse_ADMIN_MODERN.jsx
